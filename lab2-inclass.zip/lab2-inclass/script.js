import data from "./whc-sites(tangibles)-2021.json" assert {type: 'json'}

console.log(data);